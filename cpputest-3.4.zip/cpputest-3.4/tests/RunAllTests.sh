#/bin/bash
#put any pre-test execution commands here.
echo Running all tests
./AllTests $1
